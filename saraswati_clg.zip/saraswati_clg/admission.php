<?php
include("header.php");
include("menu.php");
?>
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs bg7 breadcrumbs-overlay">
    <div class="breadcrumbs-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="page-title">Admission Form</h1>
                    <ul>
                        <li>
                            <a class="active" href="index.php">Home</a>
                        </li>
                        <li>Admission Form</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->

<!-- rs-check-out Here-->
<div class="rs-check-out sec-spacer py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h3 class="title-bg">Admission Form</h3>
                <p></p>
                <div class="check-out-box">
                    <form id="contact-form" method="post">
                        <fieldset>
                            <div class="row">
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Candidate First Name<span style="color: red;">*</span></label>
                                        <input id="fname" name="fname" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Candidate Second Name</label>
                                        <input id="fname" name="sname" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Candidate Last Name</label>
                                        <input id="fname" name="lname" class="form-control" type="text">
                                    </div>
                                </div>

                            </div>
                            <div class="row">

                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Age<span style="color: red;">*</span></label>
                                        <input name="age" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Sex<span style="color: red;">*</span></label>
                                        <select name="sex" id="sex">
                                            <option value="">Select</option>
                                            <option value="">Male</option>
                                            <option value="">Female</option>
                                            <option value="">Others</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Date Of Birth<span style="color: red;">*</span></label>
                                        <input name="dob" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Father / Guardian's First Name<span style="color: red;">*</span></label>
                                        <input name="gfname" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Father / Guardian's Second Name</label>
                                        <input name="gsname" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Father / Guardian's Last Name</label>
                                        <input name="glname" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Mother,s First Name<span style="color: red;">*</span></label>
                                        <input name="mfname" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Mother,s Second Name</label>
                                        <input name="msname" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Mother,s Last Name</label>
                                        <input name="mlname" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Studen Contact No.<span style="color: red;">*</span></label>
                                        <input id="std_no" name="std_no" class="form-control" type="Studen Contact">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Parent Contact No.<span style="color: red;">*</span></label>
                                        <input name="p_no" name="p_no" class="form-control" type="Parents Contact">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="form-group">
                                        <label>Email<span style="color: red;">*</span></label>
                                        <input id="email" name="email" class="form-control" type="email">
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <h4>Addreess</h4>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Addreess Line 1<span style="color: red;">*</span></label>
                                        <input name="adrs1" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Addreess Line 2</label>
                                        <input name="adrs2" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Town/City<span style="color: red;">*</span></label>
                                        <input name="city" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>District<span style="color: red;">*</span></label>
                                        <input name="district" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>State<span style="color: red;">*</span></label>
                                        <input name="state" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <label>Postcode/ZIP<span style="color: red;">*</span></label>
                                        <input name="zip" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <label>Course Intersted<span style="color: red;">*</span></label>
                                        <select name="course" id="course">
                                            <option value="">Select Course</option>
                                            <option value="">BSc. Nursing</option>
                                        </select>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-lg-12 col-md-12 py-4">
                                    <label for="">Educational Qualification</label>
                                </div>
                                
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>10th Passing Year.<span style="color: red;">*</span></label>
                                        <input name="tenthp_year" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>10th Board Name.<span style="color: red;">*</span></label>
                                        <input name="tenth_b" class="form-control" type="text">
                                    </div>
                                </div>
                                
                                
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>10th Percentage / CGPA<span style="color: red;">*</span></label>
                                        <input name="tenth_p" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>10th Subject.<span style="color: red;">*</span></label>
                                        <input name="tenth_s" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>12th Passing Year. <span style="color: red;">*</span></label>
                                        <input name="twelve_year" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>12th Board Name.<span style="color: red;">*</span></label>
                                        <input name="twelve_b" class="form-control" type="text">
                                    </div>
                                </div>
                                
                                
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>12th Percentage / CGPA<span style="color: red;">*</span></label>
                                        <input name="twelve_p" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label>12th Subject.<span style="color: red;">*</span></label>
                                        <input name="twelve_s" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>

                        </fieldset>
                    </form>
                </div><!-- .check-out-box end -->
                <div class="shipping-box">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <p><strong>Declaration By Candidate:</strong> Event Description. A party is a gathering of people who have been invited by a host for the purposes of</p>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="rs-payment-system">

                                <center>
                                <input class="btn-send" type="submit" value="Submit">
                                </center>
                            </div>
                        </div>
                    </div>
                </div><!-- .shipping-box end -->
            </div>

        </div>
    </div>
</div>
<!-- rs-check-out End Here-->

<?php include("footer.php"); ?>