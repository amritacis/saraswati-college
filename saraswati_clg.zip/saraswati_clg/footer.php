<!-- Footer Start -->
<footer id="rs-footer" class="bg3 rs-footer">

    <!-- Footer Top -->
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12">
                    <div class="about-widget">
                        <img src="images/logo.png" alt="Footer Logo" width="110">
                        <p>B.Sc. Nursing is a 4-year long undergraduate degree course in India, focusing on preparing talented Nursing Officers. The B.Sc.</p>
                        <p class="margin-remove"> Nursing Syllabus focuses on teaching students the key skills of Nursing Human Anatomy, Nutrition, Microbiology, and Genetics.</p>
                    </div>
                </div>
                <!-- <div class="col-lg-3 col-md-12">
                    <h5 class="footer-title">RECENT NEWS</h5>
                    <div class="recent-post-widget">
                        <div class="post-item">
                            <div class="post-date">
                                <span>28</span>
                                <span>June</span>
                            </div>
                            <div class="post-desc">
                                <h5 class="post-title"><a href="#">While the lovely valley team work</a></h5>
                                <span class="post-category">Keyword Analysis</span>
                            </div>
                        </div>
                        <div class="post-item">
                            <div class="post-date">
                                <span>28</span>
                                <span>June</span>
                            </div>
                            <div class="post-desc">
                                <h5 class="post-title"><a href="#">I must explain to you how all this idea</a></h5>
                                <span class="post-category">Spoken English</span>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-5 col-md-12">
                    <h5 class="footer-title">OUR SITEMAP</h5>
                    <ul class="sitemap-widget">
                        <li class="active"><a href="index.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Home</a></li>
                        <li><a href="about.php"><i class="fa fa-angle-right" aria-hidden="true"></i>About</a></li>
                        <li><a href="course.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Courses</a></li>

                        <li><a href="gallery.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Gallery</a></li>
                        <li> <a href="course.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Courses</a></li>
                        <li><a href="criteria.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Admission Criteria</a></li>
                        <li><a href="result.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Result</a></li>
                        <li><a href="admission.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Admission</a></li>

                        <li><a href="contact.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Contact</a></li>

                    </ul>
                </div>
                <div class="col-lg-3 col-md-12">
                    <h5 class="footer-title">NEWSLETTER</h5>
                    <p>Sign Up to Our Newsletter to Get Latest Updates &amp; Services</p>
                    <form class="news-form">
                        <input type="text" class="form-input" placeholder="Enter Your Email">
                        <button type="submit" class="form-button"><i class="fa fa-arrow-right" aria-hidden="true"></i></button>
                    </form>
                </div>
            </div>
            <div class="footer-share">
                <ul>
                    <li><a href="https://www.facebook.com/scnkotputli/"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <!-- <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li> -->
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
        <div class="container">
            <div class="copyright">
                <p>&copy; 2022 Saraswati College Of Nursing. All Rights Reserved | Designed And Developed By : <a href="https://coralitsolution.com/"><img src="images/coral-logo.png" alt="" width="120"></a></p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer End -->
<!-- start scrollUp  -->
<div id="scrollUp">
    <i class="fa fa-angle-up"></i>
</div>




<!-- modernizr js -->
<script src="js/modernizr-2.8.3.min.js"></script>
<!-- jquery latest version -->
<script src="js/jquery.min.js"></script>
<!-- bootstrap js -->
<script src="js/bootstrap.min.js"></script>
<!-- owl.carousel js -->
<script src="js/owl.carousel.min.js"></script>
<!-- slick.min js -->
<script src="js/slick.min.js"></script>
<!-- isotope.pkgd.min js -->
<script src="js/isotope.pkgd.min.js"></script>
<!-- imagesloaded.pkgd.min js -->
<script src="js/imagesloaded.pkgd.min.js"></script>
<!-- wow js -->
<script src="js/wow.min.js"></script>
<!-- counter top js -->
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<!-- magnific popup -->
<script src="js/jquery.magnific-popup.min.js"></script>
<!-- rsmenu js -->
<script src="js/rsmenu-main.js"></script>
<!-- plugins js -->
<script src="js/plugins.js"></script>
<!-- main js -->
<script src="js/main.js"></script>
</body>

</html>