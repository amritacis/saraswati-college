<?php
include("header.php");
include("menu.php");
?>
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs bg7 breadcrumbs-overlay">
    <div class="breadcrumbs-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="page-title">About Us</h1>
                    <ul>
                        <li>
                            <a class="active" href="index.php">Home</a>
                        </li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->
<!-- About Us Start -->
<div id="rs-about-2" class="rs-about-2 sec-spacer py-5">
    <div class="container">
        <div class="row rs-vertical-bottom">
            <div class="col-lg-7 col-md-12">
                <div class="sec-title mb-30">
                    <h2>ABOUT US</h2>
                    <p>About Saraswati College of Nursing Kotputli.</p>
                </div>
                <p class="mobile-mb-20">
                    SCN is a pioneer institute for nursing education in India and South East Asian region. Affiliated by RUHS (Court Order).
                </p>
                <p>The College ensures complete development of the body, mind and the soul while enshrining traditional Indian values in each of its student. The primary objective of the College is to provide and promote education and research in the field of nursing.</p>

                <!-- <div class="row about-signature">
                    <div class="col-md-6">
                        <h4>Rashid Mahabub Shojib</h4>
                        <span>Vice Chancellor (vc)</span>
                    </div>

                </div> -->
                <h4>Objectives</h4>
                <p>
                    To grow as the centre of excellence in the field of Nursing, and empower the learners to lead the world in general and nation in particular in the next century towards a bright and sustainable future for mankind.
                </p>
                <p>
                    To stimulate a scientific temper by crusading against superstitions and out-dated customs like child marriage, caste system, female foeticide, dowry, gender bias, regionalism etc</p>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="about-img rs-image-effect-shine">
                    <img src="images/about/about2.jpg" alt="img02">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About Us End -->

<div class="rs-vision sec-spacer bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-12 mobile-mb-50">
                <div class="vision-imgs">
                    <img src="images/team/3.jpg" alt="img02">

                    <div class="overly-border"></div>
                </div>
            </div>
            <div class="col-lg-7 col-md-12">
                <div class="abt-title pt-3">
                    <h2>Chairman Message</h2>
                </div>
                <div class="vision-desc">
                    <p>Thank you for choosing Saraswati College of Nursing Campus/us and welcome to Saraswati college. The right time to continue your educational goal is now. The world has changed and it is never too late to study.</p>

                    <p>Our purpose is to prepare students with both theoretical and practical knowledge giving them the right tools to be successful in their carrier. We are committed to provide the support you need throughout your professional journey. We recognize, however, that for a person to be successful not only cognitive knowledge is necessary, indeed one most always search for the mission in the life.
                    </p>
                    <p>Our holistic message of education encourages our students to discover and explore their own weakness and strength and help them develop as a human being. As a student you will be a part of a friendly community of students, professors, and administration who will support you through your journey to make your dream come true.</p>
                
                    <div class="row about-signature">
                    <div class="col-md-6">
                        <h4>Rashid Mahabub Shojib</h4>
                        <span>Chairman</span>
                    </div>

                </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Vision Start -->
<div class="rs-vision sec-spacer">
    <div class="container">
        <div class="row">

            <div class="col-lg-6 col-md-12">
                <div class="abt-title">
                    <h2>OUR VISION AND MISSION</h2>
                </div>
                <div class="vision-desc">
                    <p>To bring together in one place educational facilities of the highest order for the training of personnel to attain self-sufficiency in the field of nursing, innovating technology, exploring new ideas and humanizing their experiences to create a harmonious society</p>

                    <p>The stated mission of the college is to provide
                        a stimulating active learning environment attracting all the students with exceptional desire to make a difference in the world.</p>
                    <p>To instill capacity to explore new ideas, take intellectual risk, and usher paradigm change.</p>
                    <p>The college recognizes that there are no shortcuts and what it takes to make an impact in this world. These particular characteristics delineate the multiple ways in which the college ensures mission accomplishment.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 mobile-mb-50">
                <div class="vision-img rs-animation-hover">
                    <img src="images/12.jpg" alt="img02" />

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Vision End -->

<!-- Calltoaction Start -->
<div id="rs-calltoaction" class="rs-calltoaction sec-spacer bg4 pt-5">
    <div class="container">
        <div class="rs-cta-inner text-center">
            <div class="sec-title mb-50 text-center">
                <h2 class="white-color">Director Message</h2>
                <p class="white-color"></p>
            </div>
            <p class="text-white">The world is changing rapidly and throwing up unprecedented challenges in every sphere of life. Rapid advancement in science and technology is necessitating innovative reforms in the education system.</p>
            <p class="text-white">A vision without action is only a dream and action without vision, is a waste of effort. However, we at Saraswati College of Nursing are acting on a vision to build the next generation of successful citizens. Rededicating ourselves to our mission of carrying the radiating torch of education ahead, we are now offering the best educational facilities in the historical ‘Pink City of India – Kotputli, Jaipur.</p>
            <p class="text-white">Our aim is to inspire the younger generation to launch themselves on a journey to discover their own well-being and the universe that they are a part of, thereby raising their consciousness and nurturing a love for learning and knowledge that will benefit them for the rest of their lives. We wish to encourage them to think independently, innovatively, and decisively.</p>

            <p class="text-white">The management, teachers, and students of our college are equal partners in promoting the progress of our future generation, reinforcing the cohesive nature of our multicultural nation, the largest democracy in the world.</p>

            <p class="text-white">
                Saraswati College of Nursing has carved a distinct niche for itself with a succinct philosophy “Think big, think different, think fast, think ahead and aim for the best.” I have always believed that grit and determination, combined with creative and critical thinking can help a man achieve almost everything to make this world a better place. We are committed to staying abreast with the rapidly changing society, and its educational needs and adapting ourselves to fulfill these requirements.</p>
            <p class="text-white">As a member of this college now that I have been given this opportunity, I hope to extend the journey and values of our college on the path to greatness. I am fortunate to be in a position where I can listen to and solve all the challenges that our students face, not just during their courses but also in their life in the future, and make this learning experience just a little more valuable.</p>

       
        </div>
    </div>
</div>
<!-- Calltoaction End -->
<!-- Team Start -->
<div id="rs-team" class="rs-team sec-color sec-spacer py-5">
    <div class="container">
        <div class="sec-title mb-50 text-center">
            <h2>OUR EXPERIENCED STAFFS</h2>
            <p>Considering desire as primary motivation for the generation of narratives is a useful concept.</p>
        </div>
        <div class="rs-carousel owl-carousel" data-loop="true" data-items="3" data-margin="30" data-autoplay="false" data-autoplay-timeout="5000" data-smart-speed="1200" data-dots="true" data-nav="true" data-nav-speed="false" data-mobile-device="1" data-mobile-device-nav="true" data-mobile-device-dots="true" data-ipad-device="2" data-ipad-device-nav="true" data-ipad-device-dots="true" data-md-device="3" data-md-device-nav="true" data-md-device-dots="true">
            <div class="team-item">
                <div class="team-img">
                    <img src="images/team/3.jpg" alt="team Image" />
                    <div class="normal-text">
                        <h3 class="team-name">Mr. Hemendra Rawat</h3>
                        <span class="subtitle">Assistant Professor</span>
                    </div>
                </div>
                <div class="team-content">
                    <div class="overly-border"></div>
                    <div class="display-table">
                        <div class="display-table-cell">
                            <h3 class="team-name"><a href="teachers-single.php">Mr. Hemendra Rawat</a></h3>
                            <span class="team-title">Assistant Professor</span>

                            <div class="team-social">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-item">
                <div class="team-img">
                    <img src="images/team/3.jpg" alt="team Image" />
                    <div class="normal-text">
                        <h3 class="team-name">Mr. Hemendra Rawat</h3>
                        <span class="subtitle">Assistant Professor</span>
                    </div>
                </div>
                <div class="team-content">
                    <div class="overly-border"></div>
                    <div class="display-table">
                        <div class="display-table-cell">
                            <h3 class="team-name"><a href="teachers-single.php">Mr. Hemendra Rawat</a></h3>
                            <span class="team-title">Assistant Professor</span>

                            <div class="team-social">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-item">
                <div class="team-img">
                    <img src="images/team/3.jpg" alt="team Image" />
                    <div class="normal-text">
                        <h3 class="team-name">Mr. Hemendra Rawat</h3>
                        <span class="subtitle">Assistant Professor</span>
                    </div>
                </div>
                <div class="team-content">
                    <div class="overly-border"></div>
                    <div class="display-table">
                        <div class="display-table-cell">
                            <h3 class="team-name"><a href="teachers-single.php">Mr. Hemendra Rawat</a></h3>
                            <span class="team-title">Assistant Professor</span>

                            <div class="team-social">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Team End -->
<?php include("footer.php"); ?>