<?php
include("header.php");
include("menu.php");
?>
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs bg7 breadcrumbs-overlay">
    <div class="breadcrumbs-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="page-title">Result</h1>
                    <ul>
                        <li>
                            <a class="active" href="index.php">Home</a>
                        </li>
                        <li>Result</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->

<!-- Courses Details Start -->
<div class="rs-courses-details py-5">
    <div class="container">
        <div class="row mb-30">
            <div class="col-lg-12 col-md-12">

                <div class="course-content">
                    <h3 class="course-title">SARASWATI COLLEGE OF NURSING</h3>
                    
                        <div class="row">
                            <div class="col-md-12 mobile-mb-20">
                                <div class="panel panel-red margin-bottom-40">
                                    <div class="panel-heading">
                                        <h3 class="panel-title"><i class="fa fa-user"></i> Result Detail of B.Sc. Nursing</h3>
                                    </div>
                                    <div class="panel-body" style="overflow: scroll;">
                                        <table class="table" style="margin-bottom: 0px; width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>Year</th>
                                                    <th>I Year</th>
                                                    <th>II Year</th>
                                                    <th>III Year</th>
                                                    <th>IV Year</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>2020-21</td>
                                                    <td>92%</td>
                                                    <td>99%</td>
                                                    <td>99%</td>
                                                    <td>100%</td>
                                                </tr>
                                                <tr>
                                                    <td>2019-20</td>
                                                    <td>92%</td>
                                                    <td>99%</td>
                                                    <td>98%</td>
                                                    <td>100%</td>
                                                </tr>
                                                <tr>
                                                    <td>2018-19</td>
                                                    <td>92%</td>
                                                    <td>97%</td>
                                                    <td>-</td>
                                                    <td>100%</td>
                                                </tr>
                                                <tr>
                                                    <td>2017-18</td>
                                                    <td>95%</td>
                                                    <td>92%</td>
                                                    <td>97%</td>
                                                    <td>100%</td>
                                                </tr>
                                                <tr>
                                                    <td>2016-17</td>
                                                    <td>98%</td>
                                                    <td>98%</td>
                                                    <td>99%</td>
                                                    <td>100%</td>
                                                </tr>
                                                <tr>
                                                    <td>2015-16</td>
                                                    <td>98%</td>
                                                    <td>97%</td>
                                                    <td>100%</td>
                                                    <td>99%</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>

                        </div>
                  
                </div>
                
            </div>
        </div>

    </div>
    <!-- Courses Details End -->



    <?php include("footer.php"); ?>