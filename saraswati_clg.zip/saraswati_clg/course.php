<?php
include("header.php");
include("menu.php");
?>
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs bg7 breadcrumbs-overlay">
    <div class="breadcrumbs-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="page-title">Course</h1>
                    <ul>
                        <li>
                            <a class="active" href="index.php">Home</a>
                        </li>
                        <li>Course</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->
<!-- Courses Details Start -->
<div class="rs-courses-details pt-100 pb-70">
    <div class="container">
        <div class="row mb-30">
            <div class="col-lg-12 col-md-12">
                <div class="detail-img">
                    <img src="images/a1.jpg" alt="Courses Images" />
                    <div class="course-seats">
                        60 <span>SEATS</span>
                    </div>
                </div>
                <div class="course-content">
                    <h3 class="course-title">COURSES: B.Sc (Nursing)</h3>
                    <div class="course-instructor">
                        <div class="row">
                            <div class="col-md-5 mobile-mb-20">
                                <h3 class="instructor-title">Eligibility <span class="primary-color">(Criteria)</span></h3>
                                <div class="instructor-inner">


                                </div>
                                <div class="short-desc">
                                    <p>B.Sc. Nursing is a 4-year long undergraduate degree course in India, focusing on preparing talented Nursing Officers. The B.Sc. Nursing Syllabus focuses on teaching students the key skills of Nursing Human Anatomy, Nutrition, Microbiology, and Genetics. </p>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <h3 class="instructor-title">BASIC <span class="primary-color">INFORMATION</span></h3>
                                <div class="row info-list">
                                    <div class="col-md-6">
                                        <ul>
                                            <li>
                                                <span>Fee :</span> 70,000/-P.A
                                            </li>
                                            <li>
                                                <span>Course :</span> B.Sc. Nursing
                                            </li>
                                            <li>
                                                <span>Degree :</span> 4 Year
                                            </li>
                                            <li>
                                                <span>Eligiblity :</span> 12th 
                                            </li>
                                            <li>
                                                <span>Subject :</span> Physics Chemistry Biology & English subject
                                            </li>
                                            <li>
                                                <span>Percentage :</span> Min-45% for GEN, And 40% For SC,ST
                                            </li>
                                            <li>
                                                <span>Age :</span> 17 yrs on or before 31st December of academic session.
                                            </li>

                                        </ul>
                                    </div>

                                </div>
                                <div class="apply-btn">
                                    <a href="admission.php">APPLY NOW</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="course-desc">
                    <h3 class="desc-title">OVERVIEW</h3>
                    <div class="desc-text">
                        <p>It is a job oriented course that can be pursued by students who have completed 10+2 (Science stream, with PCB subjects) from a recognized board.</p>
                        <p>Nurses are trained healthcare professionals who are capable of taking care of patients, treating them and assisting Doctors in treatment and surgery. A qualified RN (Registered Nurse) is capable of providing preventive, promotive, curative and rehabilitative services to patients (individuals) and communities.</p>
                        <p>Nurses usually work under qualified Doctors. They are also capable of making independent decisions when such a situation arrives. Nurses usually work in healthcare setups such as hospitals (Government and Private), clinics, nursing homes & NGOs. They are also capable of providing services at rural & community level healthcare initiatives and schemes.
                        </p>
                        <p>Nursing is a noble profession. Nurses bring relief into the lives of patients! It is a challenging and satisfying job. Apart from that, the job is also financially rewarding. They work tirelessly, serving patients and assisting Doctors. Each patient is unique and has his/her set of problems and diseases. Serving and treating patients suffering from different diseases is a challenging task. To perform such a daunting task, nurses stay focused and pay attention to small details.
                        </p>
                        <p>At the end of the day, a nurse brings smile and happiness on the faces of patients! For many nurses, this smile brings with it that sense of satisfaction and happiness. In short, nursing is more than just a profession. It is an opportunity to serve and treat patients. One can really bring about a change in the society through this profession.</p>
                    </div>
                    <div class="course-syllabus">
                        <h3 class="desc-title">Course Syllabus</h3>
                        <div id="accordion" class="rs-accordion-style1">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h3 class="acdn-title" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <strong>1st Year: </strong>
                                        <span>B.Sc. Nursing</span>
                                    </h3>
                                </div>
                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <h4>S. No. Subjects of Study</h4>
                                        <ol>
                                            <li>Anatomy & Physiology</li>
                                            <li>Nutrition	& Biochemistry</li>
                                            <li>Nursing Foundations</li>
                                            <li>Microbiology</li>
                                            <li> Psychology</li>
                                            <li>English</li>
                                            <li>Hindi</li>
                                            <li>Introduction to computer</li>

                                        </ol>

                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h3 class="acdn-title collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        <strong>2nd Year: </strong>
                                        <span>B.Sc. Nursing</span>
                                    </h3>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <h4>S. No. Subjects of Study</h4>
                                        <ol>
                                            <li>Medical-Surgical Nursing - I</li>
                                            <li>Community Health Nursing I</li>
                                            <li>Communication and Educational Technology</li>
                                            <li>Pharmacology Pathology and Genetics</li>
                                            <li> Sociology</li>
                                            

                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h3 class="acdn-title collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        <strong>3rd Year: </strong>
                                        <span>B.Sc. Nursing</span>
                                    </h3>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <h4>S. No. Subjects of Study</h4>
                                        <ol>
                                            <li>Medical-Surgical Nursing - II </li>
                                            <li>Child Health Nursing </li>
                                            <li>Mental Health Nursing </li>
                                            

                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header mb-0" id="headingfour">
                                    <h3 class="acdn-title collapsed" data-bs-toggle="collapse" data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                        <strong>4th Year: </strong>
                                        <span>B.Sc. Nursing</span>
                                    </h3>
                                </div>
                                <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <h4>S. No. Subjects of Study</h4>
                                        <ol>
                                            <li>Midwifery and Obstetrical Nursing </li>
                                            <li>Community Health Nursing-II </li>
                                            <li>Nursing Research and Statistics </li>
                                            <li>Management of Nursing Services and education</li>
                                            

                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial End -->
                    <!--
                	    	<div class="share-area">
                	    		<div class="row rs-vertical-middle">
                	    			<div class="col-md-5">
                	    				<h3>You Can Share It :</h3>
                	    			</div>
                	    			<div class="col-md-7">
                	    				<div class="share-inner">
                	    					<a href="#"><i class="fa fa-facebook"></i> Facebook</a>
                	    					<a href="#"><i class="fa fa-twitter"></i> Twitter</a>
                	    					<a href="#"><i class="fa fa-google"></i> Google</a>
                	    				</div>
                	    			</div>
                	    		</div>
                	    	</div>
-->
                </div>
            </div>

        </div>
    </div>

</div>
<!-- Courses Details End -->
<?php include("footer.php"); ?>