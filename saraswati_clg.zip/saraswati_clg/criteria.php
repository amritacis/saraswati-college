<?php
include("header.php");
include("menu.php");
?>
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs bg7 breadcrumbs-overlay">
    <div class="breadcrumbs-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="page-title">Admission Criteria</h1>
                    <ul>
                        <li>
                            <a class="active" href="index.php">Home</a>
                        </li>
                        <li>Admission Criteria</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->

<!-- Courses Details Start -->
<div class="rs-courses-details py-5">
    <div class="container">
        <div class="row mb-30">
            <div class="col-lg-12 col-md-12">

                <div class="course-content">
                    <h3 class="course-title">ADMISSION CRITERIA</h3>
                    <div class="course-instructor">
                        <div class="row">
                            <div class="col-md-12 mobile-mb-20">
                                <h3 class="instructor-title">SEAT <span class="primary-color">AVAILABILITY</span></h3>
                                <div class="instructor-inner">
                                    <h4>B.Sc. Nursing (Total 60 Seats)</h4>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="course-desc">
                    <h3 class="desc-title">Eligibility
                    </h3>
                    <div class="desc-text">
                        <p>
                            You can pursue Nursing right after your class 12 exam with 45% marks in science (PCBE) from any recognized board. (Physics, Chemistry, Biology, and English). The minimum age for admission in the B.Sc. Nursing program is 17 years on or before December 31, of admission year B. Sc. Nursing is a Degree Course to pursue a career in Nursing. </p>

                        <p>
                            NOTE- the Decision of Rajasthan University of Health Sciences for Eligibility And Enrolment Shall Be Final. </p>
                        <div class="course-syllabus">
                            <h3 class="desc-title" style="color: #0e79a7">Documents Required (Original)</h3>
                            <ul class="bullet_list">
                                <li>Secondary / 10th Class Marksheet</li>
                                <li>Senior Secondary / 12th Class Marksheet</li>
                                <li>GNM 1st to 3rd year &amp; Intership Marksheet</li>
                                <li>RN / RM Certificate</li>
                                <li>Diploma Certificate</li>
                                <li>SC/ST/OBC Caste Certificate.</li>
                                <li>Bonafied Certificate.</li>
                                <li>Passport Size Photographs - 05</li>
                                <li>Migration Certificate</li>
                                <li>Transfer Certificate &amp; Character Certificate</li>
                                <li>Medical fitness certificate</li>
                            </ul>

                            <h3 class="desc-title" style="color: #0e79a7">Documents Required (Original)</h3>
                            <p>Atleast Seventy-Five percent (75%) in theory classes and a hundred percent (100%) in Practical Classes / Clinical Field.

                            </p>
                            <h3 class="desc-title" style="color: #0e79a7">Fees</h3>
                            <ul class="bullet_list">
                                <li>B.Sc. Nursing 70000/-Per Year</li>
                                
                            </ul>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
    <!-- Courses Details End -->



    <?php include("footer.php"); ?>