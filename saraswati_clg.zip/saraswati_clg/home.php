<!-- Slider Area Start -->
<div id="rs-slider" class="slider-overlay-2">
    <div id="home-slider" class="rs-carousel owl-carousel" data-loop="true" data-items="4" data-margin="0" data-autoplay="false" data-autoplay-timeout="5000" data-smart-speed="1200" data-dots="false" data-nav="true" data-nav-speed="false" data-mobile-device="1" data-mobile-device-nav="true" data-mobile-device-dots="true" data-ipad-device="1" data-ipad-device-nav="true" data-ipad-device-dots="true" data-md-device="1" data-md-device-nav="true" data-md-device-dots="false">
        <!-- Item 1 -->
        <div class="item active">
            <img src="images/slider/home4/banner-5.jpg" alt="Slide1" />
            <div class="slide-content">
                <div class="display-table">
                    <div class="display-table-cell">
                        <div class="container text-center">
                            <h1 class="slider-title" data-animation-in="fadeInLeft" data-animation-out="animate-out">WELCOME TO Saraswati College Of Nursing</h1>
                            <p data-animation-in="fadeInUp" data-animation-out="animate-out" class="slider-desc">To grow as the centre of excellence in the field of Nursing, and empower the learners to lead the world in<br class="hidden-sm-dow"> general and nation in particular in the next century towards a bright and sustainable future for mankind.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Item 2 -->
        <div class="item">
            <img src="images/slider/home4/slide1.jpg" alt="Slide2" />
            <div class="slide-content">
                <div class="display-table">
                    <div class="display-table-cell">
                        <div class="container text-center">
                            <h1 class="slider-title" data-animation-in="fadeInUp" data-animation-out="animate-out">ARE YOU READY TO APPLY?</h1>
                            <p data-animation-in="fadeInUp" data-animation-out="animate-out" class="slider-desc">To stimulate a scientific temper by crusading against superstitions and out-dated customs like child marriage,<br class="hidden-sm-dow"> caste system, female foeticide, dowry, gender bias, regionalism etc.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Slider Area End -->

<!-- About Us Start -->
<div id="rs-about-2" class="rs-about-2 sec-spacer">
    <div class="container">
        <div class="row rs-vertical-bottom">
            <div class="col-lg-7 col-md-12">
                <div class="sec-title mb-30">
                    <h2>ABOUT US</h2>
                    <p>About Saraswati College of Nursing Kotputli.</p>
                </div>
                <p class="mobile-mb-20">
                    SCN is a pioneer institute for nursing education in India and South East Asian region. Affiliated by RUHS (Court Order).
                </p>
                <p>The College ensures complete development of the body, mind and the soul while enshrining traditional Indian values in each of its student. The primary objective of the College is to provide and promote education and research in the field of nursing.</p>

                <div class="view-more">
                		<a href="#">View All  <i class="fa fa-angle-double-right"></i></a>
                	</div>
                <!-- <div class="row about-signature">
                    <div class="col-md-6">
                        <h4>Rashid Mahabub Shojib</h4>
                        <span>Vice Chancellor (vc)</span>
                    </div>

                </div> -->
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="about-img rs-image-effect-shine">
                    <img src="images/about/about2.jpg" alt="img02" width="100%">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About Us End -->
<!-- Services Start -->
<div class="rs-services rs-services-style1">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="services-item rs-animation-hover">
                    <div class="services-icon">
                        <i class="fa fa-american-sign-language-interpreting rs-animation-scale-up"></i>
                    </div>
                    <div class="services-desc">
                        <h4 class="services-title">Coeducational</h4>
                        <p>Coming up together for equality

                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services-item rs-animation-hover">
                    <div class="services-icon">
                        <i class="fa fa-book rs-animation-scale-up"></i>
                    </div>
                    <div class="services-desc">
                        <h4 class="services-title">Academics</h4>
                        <p>Quality Education is given importance</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services-item rs-animation-hover">
                    <div class="services-icon">
                        <i class="fa fa-user rs-animation-scale-up"></i>
                    </div>
                    <div class="services-desc">
                        <h4 class="services-title">Activities</h4>
                        <p>99% Result Oriented

                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services-item rs-animation-hover">
                    <div class="services-icon">
                        <i class="fa fa-graduation-cap rs-animation-scale-up"></i>
                    </div>
                    <div class="services-desc">
                        <h4 class="services-title">Result</h4>
                        <p>To shape our overall personality</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Services End -->
<div class="rs-why-choose sec-spacer pt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <div class="sec-title mb-40">
                <h2>POPULAR COURSES</h2>
                    <p>Our Popular Course We Offered</p>
                </div>
                <div class="choose-desc">
                    <h3>B.Sc (Nursing)</h3>
                    <p>B.Sc. Nursing is a 4-year long undergraduate degree course in India, focusing on preparing talented Nursing Officers. The B.Sc. Nursing Syllabus focuses on teaching students the key skills of Nursing Human Anatomy, Nutrition, Microbiology, and Genetics.</p>
                    <p>It is a job oriented course that can be pursued by students who have completed 10+2 (Science stream, with PCB subjects) from a recognized board.</p>
                </div>
                <div class="row choose-list mt-50">
                    <div class="col-md-4">
                        <div class="choose-item rs-animation-hover">
                            <i class="flaticon-book-1 rs-animation-scale-up"></i>
                            <h3 class="choose-title">Eligibility  </h3>
                            <p>10+2 With Biology</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="choose-item rs-animation-hover">
                            <i class="flaticon-tool-1 rs-animation-scale-up"></i>
                            <h3 class="choose-title">Course Time</h3>
                            <p>4 Year</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="choose-item rs-animation-hover">
                            <i class="flaticon-document rs-animation-scale-up"></i>
                            <h3 class="choose-title">Fee</h3>
                            <p>70,000/- P.A</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="choose-img">
                    <img src="images/instagram/2.jpg" alt="COURSES" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Counter Up Section Start-->
<div class="rs-counter pt-5 pb-4 bg3">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <div class="counter-content">
                    <h2 class="counter-title">ACHEIVEMENTS</h2>
                    <div class="counter-text">
                        <p>This College provides a good ratio of well trained and highly educated faculty members equipped with modern technology.</p>
                    </div>
                    <div class="counter-img rs-image-effect-shine">
                        <img src="images/a1.jpg" alt="Counter Discussion">
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 mt-80">
                <div class="row">
                    <div class="col-md-6">
                        <div class="rs-counter-list">
                            <h2 class="counter-number plus">60</h2>
                            <h4 class="counter-desc">Certified Teachers</h4>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="rs-counter-list">
                            <h2 class="counter-number plus">10</h2>
                            <h4 class="counter-desc">Experinces</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="rs-counter-list">
                            <h2 class="counter-number plus">900</h2>
                            <h4 class="counter-desc">Students Enrolled</h4>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="rs-counter-list">
                            <h2 class="counter-number plus">3675</h2>
                            <h4 class="counter-desc">Satisfied Parents</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counter Down Section End -->
<div id="rs-learning-objectives" class="rs-learning-objectives pt-5 pb-4">
    <div class="container">
        <div class="sec-title mb-50">
            <h2>LEARNING OBJECTIVES</h2>
            <p>At Saraswati College of Nursing the students are endowed with modern infra and convenient amenities that make their life 'go easy' in college hours, alongside make learning more interesting.</p>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <i class="glyph-icon flaticon-tool"></i>
                    <h4 class="courses-title"><a href="#">Best Education System</a></h4>
                    <p>The Saraswati College of Nursing Kotputli provides high academic standards to its students. </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <i class="glyph-icon flaticon-book"></i>
                    <h4 class="courses-title"><a href="#">Affordable Fees</a></h4>
                    <p>We have a well-structured and comprehensive fee schedule that includes the admission, tuition, and registration fees.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <i class="glyph-icon flaticon-people"></i>
                    <h4 class="courses-title"><a href="#">Experinced Faculty</a></h4>
                    <p>At SCN the members of the academic staff come from accomplished backgrounds with vast experience.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <i class="glyph-icon flaticon-tool-2"></i>
                    <h4 class="courses-title"><a href="#">Travelling Facilities </a></h4>
                    <p>SCN provides safe and reliable air-conditioned bus transportation to students who wish to avail this facility.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <i class="glyph-icon flaticon-tool-1"></i>
                    <h4 class="courses-title"><a href="#">Scholarship  Faciltites</a></h4>
                    <p>It helps in empowering your academic and career goals by removing the financial barrier. </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <i class="flaticon-book-1"></i>
                    <h4 class="courses-title"><a href="#">SPACIOUS LIBRARY</a></h4>
                    <p>Our reading rooms are well equipped with books, magazines and periodicals dealing with diverse topics of interest.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Instagram Start -->
<div id="rs-instagram" class="rs-instagram mb-4">

    <div class="rs-carousel owl-carousel" data-loop="true" data-items="4" data-margin="0" data-autoplay="true" data-autoplay-timeout="3000" data-smart-speed="1200" data-dots="false" data-nav="false" data-nav-speed="false" data-mobile-device="2" data-mobile-device-nav="false" data-mobile-device-dots="false" data-ipad-device="3" data-ipad-device-nav="false" data-ipad-device-dots="false" data-md-device="4" data-md-device-nav="false" data-md-device-dots="false">
        <div class="instagram-item">
            <a href="#">
                <img src="images/instagram/1.jpg" alt="Instagram Image">
            </a>
        </div>
        <div class="instagram-item">
            <a href="#">
                <img src="images/instagram/2.jpg" alt="Instagram Image">
            </a>
        </div>
        <div class="instagram-item">
            <a href="#">
                <img src="images/instagram/3.jpg" alt="Instagram Image">
            </a>
        </div>
        <div class="instagram-item">
            <a href="#">
                <img src="images/instagram/4.png" alt="Instagram Image">
            </a>
        </div>
    </div>

</div>
<!-- Instagram End -->
<!-- Calltoaction Start -->
<div id="rs-calltoaction" class="rs-calltoaction sec-spacer bg4 pt-5">
    <div class="container">
        <div class="rs-cta-inner text-center">
            <div class="sec-title mb-50 text-center">
                <h2 class="white-color">Director Message</h2>
                <p class="white-color"></p>
            </div>
            <p class="text-white">The world is changing rapidly and throwing up unprecedented challenges in every sphere of life. Rapid advancement in science and technology is necessitating innovative reforms in the education system.</p>
            <p class="text-white">A vision without action is only a dream and action without vision, is a waste of effort. However, we at Saraswati College of Nursing are acting on a vision to build the next generation of successful citizens. Rededicating ourselves to our mission of carrying the radiating torch of education ahead, we are now offering the best educational facilities in the historical ‘Pink City of India – Kotputli, Jaipur.</p>
            <p class="text-white">Our aim is to inspire the younger generation to launch themselves on a journey to discover their own well-being and the universe that they are a part of, thereby raising their consciousness and nurturing a love for learning and knowledge that will benefit them for the rest of their lives. We wish to encourage them to think independently, innovatively, and decisively.</p>

            <a class="cta-button" href="about.php">See More</a>
        </div>
    </div>
</div>
<!-- Calltoaction End -->

<!-- Team Start -->
<div id="rs-team" class="rs-team sec-color sec-spacer pt-5">
    <div class="container">
        <div class="sec-title mb-50 text-center">
            <h2>OUR EXPERIENCED STAFFS</h2>
            <p>Considering desire as primary motivation for the generation of narratives is a useful concept.</p>
        </div>
        <div class="rs-carousel owl-carousel" data-loop="true" data-items="3" data-margin="30" data-autoplay="false" data-autoplay-timeout="5000" data-smart-speed="1200" data-dots="true" data-nav="true" data-nav-speed="false" data-mobile-device="1" data-mobile-device-nav="true" data-mobile-device-dots="true" data-ipad-device="2" data-ipad-device-nav="true" data-ipad-device-dots="true" data-md-device="3" data-md-device-nav="true" data-md-device-dots="true">
            <div class="team-item">
                <div class="team-img">
                    <img src="images/team/3.jpg" alt="team Image" />
                    <div class="normal-text">
                        <h3 class="team-name">Mr. Hemendra Rawat</h3>
                        <span class="subtitle">Assistant Professor</span>
                    </div>
                </div>
                <div class="team-content">
                    <div class="overly-border"></div>
                    <div class="display-table">
                        <div class="display-table-cell">
                            <h3 class="team-name"><a href="teachers-single.php">Mr. Hemendra Rawat</a></h3>
                            <span class="team-title">Assistant Professor</span>

                            <div class="team-social">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-item">
                <div class="team-img">
                    <img src="images/team/3.jpg" alt="team Image" />
                    <div class="normal-text">
                        <h3 class="team-name">Mr. Hemendra Rawat</h3>
                        <span class="subtitle">Assistant Professor</span>
                    </div>
                </div>
                <div class="team-content">
                    <div class="overly-border"></div>
                    <div class="display-table">
                        <div class="display-table-cell">
                            <h3 class="team-name"><a href="teachers-single.php">Mr. Hemendra Rawat</a></h3>
                            <span class="team-title">Assistant Professor</span>

                            <div class="team-social">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-item">
                <div class="team-img">
                    <img src="images/team/3.jpg" alt="team Image" />
                    <div class="normal-text">
                        <h3 class="team-name">Mr. Hemendra Rawat</h3>
                        <span class="subtitle">Assistant Professor</span>
                    </div>
                </div>
                <div class="team-content">
                    <div class="overly-border"></div>
                    <div class="display-table">
                        <div class="display-table-cell">
                            <h3 class="team-name"><a href="teachers-single.php">Mr. Hemendra Rawat</a></h3>
                            <span class="team-title">Assistant Professor</span>

                            <div class="team-social">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Team End -->
<!-- Testimonial Start -->
<div id="rs-testimonial" class="rs-testimonial bg5 sec-spacer pt-5">
    <div class="container">
        <div class="sec-title mb-50 text-center">
            <h2 class="white-color">WHAT PEOPLE SAYS</h2>
            <p class="white-color">What our other clients have said about us</p>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="rs-carousel owl-carousel" data-loop="true" data-items="2" data-margin="30" data-autoplay="true" data-autoplay-timeout="5000" data-smart-speed="1200" data-dots="true" data-nav="true" data-nav-speed="false" data-mobile-device="1" data-mobile-device-nav="true" data-mobile-device-dots="true" data-ipad-device="2" data-ipad-device-nav="true" data-ipad-device-dots="true" data-md-device="2" data-md-device-nav="true" data-md-device-dots="true">
                    <div class="testimonial-item">

                        <div class="testi-desc">
                            <h4 class="testi-name">Luise Henrikes</h4>
                            <p>
                                Etiam non elit nec augue tempor gravida et sed velit. Aliquam tempus eget lorem ut malesuada. Phasellus dictum est sed libero posuere dignissim.
                            </p>
                        </div>
                    </div>
                    <div class="testimonial-item">

                        <div class="testi-desc">
                            <h4 class="testi-name">Aliana D’suza</h4>
                            <p>
                                Tempor non elit nec augue nec gravida et sed velit. Aliquam tempus eget lorem ut malesuada. Phasellus dictum est sed libero posuere dignissim.
                            </p>
                        </div>
                    </div>
                    <div class="testimonial-item">

                        <div class="testi-desc">
                            <h4 class="testi-name">Aliana D’suza</h4>
                            <p>
                                Tempor non elit nec augue nec gravida et sed velit. Aliquam tempus eget lorem ut malesuada. Phasellus dictum est sed libero posuere dignissim.
                            </p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial End -->


<div id="rs-latest-news" class="rs-latest-news sec-spacer py-5">
    <div class="container">
        <div class="sec-title-2 text-right mb-50">
            <h2>OUR LASTEST NEWS AND UPDATES</h2>
            <p>Get latest news and update of our college here. </p>

        </div>
        <div class="row">

            <div class="col-md-12">
                <div class="news-list-block">
                    <marquee direction="up" height="250px" scrollamount="4" onmouseover="this.stop();" onmouseout="this.start();">


                        <div class="news-list-item">

                            <div class="news-content">
                                <h5 class="news-title">ADMISSION OPEN FOR Students</h5>
                                <div class="news-date">
                                    <i class="fa fa-calendar-check-o"></i>
                                    <span>June 28, 2022</span>
                                </div>
                                <div class="news-desc">
                                    <p>
                                        The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="news-list-item">

                            <div class="news-content">
                                <h5 class="news-title">ADMISSION OPEN FOR Students</h5>
                                <div class="news-date">
                                    <i class="fa fa-calendar-check-o"></i>
                                    <span>June 28, 2022</span>
                                </div>
                                <div class="news-desc">
                                    <p>
                                        The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="news-list-item">

                            <div class="news-content">
                                <h5 class="news-title">ADMISSION OPEN FOR Students</h5>
                                <div class="news-date">
                                    <i class="fa fa-calendar-check-o"></i>
                                    <span>June 28, 2022</span>
                                </div>
                                <div class="news-desc">
                                    <p>
                                        The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </marquee>
                </div>
            </div>
        </div>
    </div>
</div>