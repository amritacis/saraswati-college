<?php
include("header.php");
include("menu.php");
?>
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs bg7 breadcrumbs-overlay">
    <div class="breadcrumbs-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="page-title">Document</h1>
                    <ul>
                        <li>
                            <a class="active" href="index.php">Home</a>
                        </li>
                        <li>Document</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->

<div id="rs-latest-news-style7" class="rs-latest-news-style7 sec-spacer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <h2 class="uppercase title py-4">Document Required</h2>
            </div>
            <div class="col-lg-6">
               
                <div class="rs-latest-list">
                    <div class="event-item-new mb-20">
                        
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"> <span class="day">01.</span> Aloutment Paper from RUHS</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">02</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">02.</span> 500Rs/- Challan(1 Copy)</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">03</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">03.</span> Fess</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">04</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">04.</span> Examition Form Print</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">05</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">05.</span> 10th Marksheet</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">06</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">06.</span> 12th Marksheet</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">07</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">07.</span> Caste Certificate</a>
                            </h4>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">

                <div class="rs-latest-list">
                   
                    
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">08</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">08.</span> Bonafied Certificate</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">08</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">09.</span> T.C</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">09</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">10.</span> Health Certificate</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">10</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">11.</span> Aadhar Card Copy</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">11</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">12.</span> Passport Size Photo-6</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">12</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">13.</span> Mobile No.</a>
                            </h4>

                        </div>
                    </div>
                    <div class="event-item-new mb-20">
                        <!-- <div class="event-date">
                            <div class="vertical-align">
                                <span class="day">13</span>

                            </div>
                        </div> -->
                        <div class="event-des">
                            <h4 class="title">
                                <a href="#"><span class="day">14.</span> Email ID</a>
                            </h4>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>